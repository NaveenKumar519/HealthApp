from django.contrib import admin
from .models import brain_stroke
# Register your models here.
admin.site.register(brain_stroke)
